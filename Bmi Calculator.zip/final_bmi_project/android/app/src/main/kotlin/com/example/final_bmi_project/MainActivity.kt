package com.example.final_bmi_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
