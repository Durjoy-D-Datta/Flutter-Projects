package com.example.fromdegine

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
