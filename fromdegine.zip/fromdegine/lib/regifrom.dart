import 'package:flutter/material.dart';

class RForm extends StatefulWidget {
  const RForm({super.key});

  @override
  State<RForm> createState() => _RFormState();
}

class _RFormState extends State<RForm> {
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
          key: _formKey,
          child: Column(
            children: [
              Text(
                'Registration From',

                // style: ,
              ),
              ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      // If the form is valid, display a snackbar. In the real world,
                      // you'd often call a server or save the information in a database.
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Processing Data')),
                      );
                    }
                  },
                  child: Text('Button')),
              TextFormField(
                decoration: InputDecoration(border: OutlineInputBorder()),
                validator: (value) {
                  if (value == null ||
                      // int.tryParse(value) == null ||
                      value.isEmpty) {
                    return 'Sala kanar bacca likh kicu age';
                  } else if (value == 'siam') {
                    return 'Tanki';
                  }
                  return null;
                },
              ),
              TextFormField(
                validator: (value) {
                  if (value == null ||
                      int.tryParse(value) == null ||
                      value.isEmpty) {
                    return 'Sala kanar bacca likh kicu age';
                  } else if (value == 'siam') {
                    return 'Tanki';
                  }
                  return null;
                },
              ),
            ],
          )),
    );
  }
}
