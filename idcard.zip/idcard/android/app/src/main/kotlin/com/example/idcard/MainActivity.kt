package com.example.idcard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
