import 'dart:ui';

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      backgroundColor: Color.fromARGB(221, 9, 209, 159),
      body: Center(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.only(top: 100),
              child: CircleAvatar(
                radius: 70,
                backgroundImage: AssetImage('images/dj.jpg'),
                //child: Image.asset('images/dj.jpg'),
              ),
            ),
            Container(
              child: Text(
                'Durjoy Datta',
                style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic,
                    fontFamily: ('Ourfont')),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              child: Text(
                'Flutter Developer',
                style: TextStyle(fontSize: 18, fontFamily: ('Ourfont')),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 20, left: 20, right: 20),
              color: Color.fromARGB(253, 252, 249, 249),
              height: 35,
              width: double.infinity,
              child:
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(
                    margin: EdgeInsets.only(left: 15), child: Icon(Icons.call)),
                SizedBox(
                  width: 10,
                ),
                Container(
                  child: Text(
                    '+8801685753773',
                    style: TextStyle(fontFamily: ('Ourfont')),
                  ),
                )
              ]),
            ),
            Container(
              margin: EdgeInsets.only(top: 5, left: 20, right: 20, bottom: 10),
              color: Color.fromARGB(253, 252, 249, 249),
              height: 35,
              width: double.infinity,
              child:
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(
                    margin: EdgeInsets.only(left: 15),
                    child: Icon(Icons.email)),
                SizedBox(
                  width: 15,
                ),
                Container(
                  alignment: Alignment.center,
                  child: Text(
                    'dattadurjoy111@gmail.com',
                    style: TextStyle(fontFamily: ('Ourfont')),
                    textAlign: TextAlign.center,
                  ),
                )
              ]),
            ),
            Container(
              child: Text(
                'Other Accounts',
                style: TextStyle(fontFamily: 'Ourfont'),
              ),
            )
          ],
        ),
      ),
    ),
  ));
}
