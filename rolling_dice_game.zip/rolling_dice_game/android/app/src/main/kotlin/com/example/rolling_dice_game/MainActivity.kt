package com.example.rolling_dice_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
